DevOps Assignment: Kubernetes, OpenTelemetry, and Kafka

1. Overview

The goal of this project is to deploy a sample web application and a Kafka cluster on Kubernetes and monitor them using OpenTelemetry.

I built a Flask application, deployed it on Minikube, set up Kafka using Strimzi, and configured a producer to send sample messages to a Kafka topic. I also configured an OpenTelemetry Collector to collect application, Kafka, and Kubernetes infrastructure metrics.

The Collector currently uses the debug exporter to inspect collected telemetry locally. Exporting metrics to KloudMate and setting up dashboards remain incomplete because the required account and project access was unavailable.

2. Architecture

The project consists of three main components:

- Flask application: A Python web application deployed on Kubernetes. It exposes endpoints for basic requests and health checks, along with a `/metrics` endpoint for Prometheus-compatible metrics.
- Kafka: A Kafka cluster deployed using Strimzi. A producer pod periodically sends sample messages to the `my-topic` topic.
- OpenTelemetry Collector: Collects Flask application metrics, Kafka broker metrics, and Kubernetes infrastructure metrics. The collected telemetry is currently written to the Collector's debug output.
3. Technologies Used

- Python and Flask
- Docker
- Kubernetes and Minikube
- Apache Kafka and Strimzi
- Prometheus client library
- OpenTelemetry Collector
- PowerShell

4. Flask Application

The Flask application exposes the following endpoints:

Endpoint     Description
 /          Confirms that the application is running. 
 /health    Returns the application's health status. 
 /hello     Returns a sample greeting. 
 /metrics   Exposes application metrics in Prometheus format. 

Custom metrics track HTTP request counts and request durations.

The application is packaged as a Docker image and deployed to Kubernetes through a Deployment and Service.

5. Kafka Setup

Kafka is deployed in the kafka namespace using Strimzi. The cluster is named `my-cluster`, and the sample topic is `my-topic`.
A separate producer pod periodically sends sample messages to the topic. The Kafka broker also exposes a metrics endpoint on port `9404`.
The current setup uses a single broker, which is sufficient for a local demonstration but does not provide broker redundancy.
There is no separate Kafka consumer in this implementation, so consumer-group lag monitoring is not configured.


6. OpenTelemetry Configuration

The OpenTelemetry Collector runs in the `observability` namespace.

It is configured to collect metrics from three sources:

Source        Collection method
Flask         Prometheus scraping of the application's /metrics endpoint 
Kafka         Prometheus scraping using Kubernetes pod discovery 
Kubernetes    Kubelet statistics receiver for node, pod, and container metrics 

A batch processor is configured in the metrics pipeline. The current exporter is the debug exporter, which allows collected telemetry to be inspected in the Collector logs.

During testing, the Collector output included Flask metric names such as http_requests_total and http_request_duration_seconds, Kafka metrics with names beginning with kafka_server_, and Kubernetes infrastructure metrics such as k8s.node.network.errors and k8s.pod.network.errors.

These observations provide evidence that telemetry is being collected locally. They do not establish that the telemetry is being exported to an external monitoring platform.

KloudMate export configuration and dashboard creation remain incomplete.

7. Running the Project

The following commands use Windows PowerShell. They describe how to inspect and test an environment in which the required software and Kubernetes resources have already been configured.

Start Minikube

powershell
minikube start
kubectl cluster-info
kubectl get nodes


Check the Running Workloads

powershell
kubectl get pods
kubectl get pods -n kafka
kubectl get pods -n observability


Test the Flask Application

Check the Deployment and Service:

powershell
kubectl get deployments
kubectl get services
kubectl get pods


Forward local port `5000` to the Flask Service:

powershell
kubectl port-forward service/devops-flask-service 5000:80


Keep this terminal open. In a second PowerShell window, test the endpoints:

powershell
Invoke-RestMethod http://localhost:5000/
Invoke-RestMethod http://localhost:5000/health
Invoke-RestMethod http://localhost:5000/hello


To view the application's metrics:

powershell
(Invoke-WebRequest http://localhost:5000/metrics -UseBasicParsing).Content


Generate test requests:

powershell
1..5 | ForEach-Object {
    Invoke-RestMethod http://localhost:5000/
    Invoke-RestMethod http://localhost:5000/hello
}


Check the custom metrics:

powershell
(Invoke-WebRequest http://localhost:5000/metrics -UseBasicParsing).Content |
    Select-String "http_requests_total|http_request_duration_seconds"


Check Kafka

List the Kafka resources and inspect the producer:

powershell
kubectl get pods -n kafka
kubectl get kafka -n kafka
kubectl get kafkatopic my-topic -n kafka
kubectl logs kafka-producer -n kafka --tail=30


To inspect the Kafka topic offset:

powershell
kubectl exec -n kafka my-cluster-dual-role-0 -- bin/kafka-get-offsets.sh --bootstrap-server my-cluster-kafka-bootstrap:9092 --topic my-topic


To inspect the Kafka broker metrics endpoint, open another terminal:

powershell
kubectl port-forward pod/my-cluster-dual-role-0 9404:9404 -n kafka


Keep the port-forward window running. In a second terminal, run:

powershell
(Invoke-WebRequest http://localhost:9404/metrics -UseBasicParsing).Content |
    Select-String "kafka_server|kafka_topic|kafka_network"


These commands test access to the broker's metrics endpoint. They do not independently establish that the OpenTelemetry Collector is scraping it successfully.

Check OpenTelemetry

Check the Collector Deployment and its logs:

powershell
kubectl get deployment otel-collector -n observability
kubectl get pods -n observability
kubectl logs deployment/otel-collector -n observability --since=10m


Look for application metrics:

powershell
kubectl logs deployment/otel-collector -n observability --since=10m |
    Select-String "http_requests_total|http_request_duration_seconds"


Look for Kafka metrics:

powershell
kubectl logs deployment/otel-collector -n observability --since=10m |
    Select-String "kafka_server|kafka_topic|kafka_network"


Look for Kubernetes infrastructure metrics:

powershell
kubectl logs deployment/otel-collector -n observability --since=10m |
    Select-String "k8s.node.cpu.time|k8s.node.memory.usage|container.memory.usage"


These commands help identify expected metric names in the Collector output. A missing match does not necessarily prove that collection has failed, because the output depends on the configured receivers, available metrics, and logging format.

Environment Setup Notes

For a fresh environment, install Minikube, configure Docker image availability inside the Minikube cluster, and install the Strimzi operator before applying Kafka custom resources.

The Kafka cluster and topic manifests depend on the Strimzi custom resource definitions and operator being installed. The Flask Deployment also expects the devops-flask-app:latest image to be available to the cluster.

The commands above are primarily for inspecting and testing an already configured environment; they do not install every dependency or recreate the entire setup from scratch.

8. Current Status

The Flask application, Kafka broker, producer, and OpenTelemetry Collector have been configured in the local Kubernetes environment.

The Flask endpoints and metrics endpoint have been tested. The Kafka topic offset increased during testing, indicating that messages were being written to the topic.

The OpenTelemetry Collector output included Flask application metric names, Kafka metric names, and Kubernetes infrastructure metric names, providing evidence of local telemetry collection.

However, sustained Kafka producer reliability has not been fully verified, and successful export to an external monitoring platform has not been established.

KloudMate integration and dashboard creation remain incomplete because the required account and project access was unavailable. Consumer-group lag is not monitored because the project does not include a separate consumer.

This implementation is intended as a local demonstration rather than a production-ready deployment.

9. Possible Improvements

- Complete the KloudMate integration and create dashboards for application, Kafka, and infrastructure metrics.
- Add consumer-group lag monitoring if required.
- Investigate Kafka producer timeouts and improve delivery reliability.
- Improve Kafka availability and security for a production environment.
- Add or refine Kubernetes resource limits and readiness probes.
- Add a documented setup script to make the environment easier to reproduce from scratch.
