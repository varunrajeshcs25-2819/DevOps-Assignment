
from flask import Flask, jsonify, request, g, Response
import logging
import time

from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST

app = Flask(__name__)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

REQUEST_COUNT = Counter(
    "http_requests_total",
    "Total number of HTTP requests",
    ["method", "endpoint", "status_code"]
)

REQUEST_LATENCY = Histogram(
    "http_request_duration_seconds",
    "HTTP request duration in seconds",
    ["method", "endpoint"]
)


@app.before_request
def start_timer():
    if request.path != "/metrics":
        g.request_start_time = time.perf_counter()


@app.after_request
def record_metrics(response):
    if request.path != "/metrics":
        method = request.method
        endpoint = request.endpoint or "not_found"
        status = str(response.status_code)

        REQUEST_COUNT.labels(method, endpoint, status).inc()

        elapsed = time.perf_counter() - getattr(
            g, "request_start_time", time.perf_counter()
        )
        REQUEST_LATENCY.labels(method, endpoint).observe(elapsed)

    return response


@app.route("/")
def home():
    logger.info("Home endpoint requested")
    return jsonify({
        "message": "DevOps Take-Home Application is running!"
    })


@app.route("/health")
def health():
    logger.info("Health check requested")
    return jsonify({"status": "healthy"})


@app.route("/hello")
def hello():
    logger.info("Hello endpoint requested")
    return jsonify({
        "message": "Hello from the Kubernetes application!"
    })


@app.route("/metrics")
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
